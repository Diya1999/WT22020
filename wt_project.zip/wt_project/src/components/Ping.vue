<template>
  <div>
    <p>{{ msg }}</p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'Ping',
  data() {
    return {
      msg: '',
    };
  },
  methods: {
    getMessage() {
      const path = 'http://localhost:5000/ping';
      axios.get(path)
        .then((res) => {
          this.msg = res.data;
        })
        .catch((error) => {
          // eslint-disable-next-line
          console.error(error);
        });
    },
    retrieveAllCustomer: function () {
    var comp = this;
    var xhr = new XMLHttpRequest();

            var url = 'http://localhost:5000/ping';
            xhr.open("GET", url);
            xhr.onreadystatechange = function () {
                if (this.readyState === XMLHttpRequest.DONE) {
                    if (this.status === 200) {
                        comp.msg = JSON.parse(this.responseText);
                        //console.log(this.responseText);
                        console.log(comp.msg);
                    } else {
                        console.log(this.status, this.statusText);
                    }
                }
            };
            xhr.send();
        },
  },
  created() {
    //this.getMessage();
    this.retrieveAllCustomer();
  },
};
</script>