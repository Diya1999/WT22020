<template>
    <v-container fluid fill-height class="home-hero" style="max-height: 100vh;">
        <v-layout justify-center align-center column pa-5>
            <div class="display-2 font-weight-black white--text text-xs-center">HEADING 1</div>
            <div class="display-2 font-weight-black white--text text-xs-center mb-3">HEADING 2</div>
            <div class="display-1 font-weight-bold white--text text-xs-center">SUBHEADING </div>
           <!-- <v-btn fab class="mt-10 blue-grey lighten-1">
            <v-icon large color="white">expand_more</v-icon>
            </v-btn>-->
        </v-layout>
    </v-container>
</template>

<script>
export default {
    name: 'HomeHero'
};
</script>

<style scoped>
.home-hero {
    background: url('https://thumbs.gfycat.com/BigheartedHospitableCrab-size_restricted.gif');
    background-size: cover;
    width: 100%;
    height: 100%;
}

</style>