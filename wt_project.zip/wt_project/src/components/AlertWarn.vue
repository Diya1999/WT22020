<template>
  <div>
  <v-alert type="error">
       {{ message }}
      </v-alert>
    <br>
  </div>
</template>

<script>
export default {
    name: 'AlertWarn',
  props: ['message']
};
</script>

