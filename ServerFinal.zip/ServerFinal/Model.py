from flask import Flask
from flask import send_file
from flask import make_response
import model1
from flask import request
from flask import Flask, render_template
app = Flask(__name__)

@app.route('/predict', methods=['GET','POST'])
def pred():
    content = request.get_json()
    gender=content['gender']
    age=content['age']
    hypertension=content['hypertension']
    heart=content['heart_disease']
    married=content['ever_married']
    work=content['work_type']
    residence=content['Residence_type']
    glucose=content['avg_glucose_level']
    bmi=content['bmi']
    #smoking=request.args.get('smoking_status')
    bytes_obj = model1.prediction(gender,age,hypertension,heart,married,work,residence,glucose,bmi) 
    return bytes_obj

@app.route('/metrics', methods=['GET'])
def met():
    bytes_obj = model1.metrics1() 
    return bytes_obj

@app.route('/correlation', methods=['GET'])
def corr():
    bytes_obj = model1.corr() 
    return send_file(bytes_obj,
                     attachment_filename='plot.png',
                     mimetype='image/png')

@app.route('/confusion', methods=['GET'])
def conf():
    bytes_obj = model1.confusion_matrix_rep() 
    return send_file(bytes_obj,
                     attachment_filename='plot.png',
                     mimetype='image/png')


if __name__ == '__main__':
    app.run(debug=False)