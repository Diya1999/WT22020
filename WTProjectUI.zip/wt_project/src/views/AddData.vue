<template>
    <v-container fluid fill-height class="sign-in">
        <v-layout align-center justify-center>
           
            <v-flex xs12 sm8 md8>
                 <v-select 
                                v-model="operation"
                                :items="operationa"
                                label="Choose action"
                                class="styled-input1"
                            ></v-select>
                    <div v-if="operation === 'Add Data' ">
                    <br>
                    <h1> Add Data </h1>
                    <br>
                     <v-card class="elevation-24">
                         <v-card-text class="cardText blue-grey darken-4" >
                        <v-form ref="form" >
                         <v-text-field v-model="id" name="id" label="Id" dark required>
                            </v-text-field>
                             <v-row >
                            <v-select 
                                dark
                                v-model="gender"
                                :items="gendera"
                                label="Gender"
                                class="styled-input1"
                            ></v-select>
                            <v-spacer></v-spacer>
                             <v-select 
                                dark
                                v-model="Residence_type"
                                :items="residencea"
                                label="Residence"
                                class="styled-input1"
                            ></v-select>
                            </v-row>
                            <v-text-field
                                dark
                                label="Age"
                                outlined
                                dense
                                v-model="age"
                                class="styled-input"
                            ></v-text-field>
                            <v-row >
                                <v-switch dark class="ma-4" v-model="hypertension" label="Hypertension"></v-switch>
                                <v-switch dark class="ma-4" v-model="ever_married" label="Ever been married"></v-switch>
                                <v-switch dark class="ma-4" v-model="heart_disease" label="Any heart disease"></v-switch>
                            </v-row>
                            <v-select 
                                dark
                                v-model="smoking_status"
                                :items="smokea"
                                label="Status on smoking"
                                class="styled-input1"
                            ></v-select>
                             <v-radio-group label="Work Type" dark v-model="work_type">
                                <v-radio
                                        v-for="(item, index) in work_typea"
                                        :key=index
                                        :label="` ${item}`"
                                        :value="` ${item}`"
                                    ></v-radio>
                            </v-radio-group>
                            <v-text-field dark v-model="bmi" name="bmi" label="BMI" filled required>
                            </v-text-field>
                             <v-text-field dark v-model="avg_glucose_level" name="glucose" label="Average Glucose Level" filled required>
                            </v-text-field>
                            <v-checkbox
                                    dark
                                    v-model="stroke"
                                    label="Stroke"
                                    required
                            ></v-checkbox>
                            
                        </v-form>
                        <v-spacer></v-spacer>
                        <v-row>
                        <v-btn color="green" @click="onSubmit">Add Data</v-btn>
                        <v-spacer></v-spacer>
                         <v-btn color="red" @click="reset">Reset</v-btn>
                         </v-row>
                         </v-card-text>
                        </v-card >
                        <div v-if="add_message === 'Record added!' ">
                            <alert :message="add_message"></alert>
                        </div>
                        <div v-if="add_message === 'ID already present!!' ">
                            <alert_warn :message="add_message"></alert_warn>
                        </div>
                </div>

                <div v-if="operation === 'Delete Entry' ">
                    <br>
                    <h1> Delete Entry </h1>
                    <br>
                     <v-card class="elevation-24">
                         <v-card-text class="cardText blue-grey darken-4" >
                        <v-form ref="form" v-model="valid">
                         <v-text-field v-model="id1" name="id1" label="Id" dark required>
                            </v-text-field>
                        <v-checkbox
                            v-model="del"
                            @change="onCheck"
                            :rules="[v => !!v || 'You must agree to continue!']"
                            label="Confirm Delete"
                            required
                            dark
                        ></v-checkbox>
                        </v-form>
                        <v-spacer></v-spacer>
                       <v-list class="blue-grey darken-4">
                            <template v-for="(val,index) in response_delete">
                                <v-list-item :key="index" class="blue-grey darken-4" dark>
                                    <v-list-item-content>
                                        {{index}} : {{val}}
                                    </v-list-item-content>
                                </v-list-item>
                                <v-divider :key="`divider-${index}`"></v-divider>
                            </template>
                        </v-list>
                        <v-spacer></v-spacer>
                        <v-row>
                        <v-btn color="red" :disabled="!valid" @click="onDelete">Delete Entry</v-btn>
                        <v-spacer></v-spacer>
                         <v-btn color="green" @click="reset">Reset</v-btn>
                         </v-row>
                         </v-card-text>
                        </v-card >
                        <div v-if="del_message === 'Deleted successfully!' ">
                            <alert :message="del_message"></alert>
                        </div>
                        <div v-if="del_message === 'No such ID!!' ">
                            <alert_warn :message="del_message"></alert_warn>
                        </div>
                        <v-spacer></v-spacer>
                </div>
           </v-flex>
        </v-layout>
    </v-container>
</template>

<script>
import axios from 'axios';
import AlertAdd from '@/components/AlertAdd';
import AlertWarn from '@/components/AlertWarn';

export default {
  data() {
    return {
        valid:false,
        add_message:'',
        del_message:'',
        msg:'',
        response_delete:'',
         id:'',
          id1:'',
         gender:null,
         Residence_type:null,
         age:'',
         hypertension:false,
         ever_married:false,
         heart_disease:false,
         work_type:null,
         avg_glucose_level:'',
         bmi:'',
         operation:'',
         smoking_status:'',
         stroke:false,
         del:false,
         response:[],
        gendera: [
      'Male',
      'Female'
    ],
     smokea: [
      'never smoked',
      'formerly smoked',
      'smokes'
    ],
     operationa: [
       'Add Data' ,
      'Delete Entry'
    ],

     work_typea: [
      'children',
      'Private',
      'Self-employed'    //fill up the rest
    ],

    residencea: [
      'Urban',
      'Rural'//fill up the rest
    ]
    };
  },
  methods: {
    initForm() {
         this.id='';
         this.id1='';
         this.gender=null;
         this.Residence_type=null;
         this.age='';
         this.hypertension=false;
         this.ever_married=false;
         this.heart_disease=false;
         this.work_type=null;
         this.avg_glucose_level='';
         this.bmi='';
         this.smoking_status='';
         this.stroke=false;
         this.del=false;
         this.response_delete='';
    },
    reset(){
        this.initForm();
        this.add_message='';
        this.del_message='';
    },
    addData(payload) {
      const path = 'http://localhost:5000/addData';
      axios.post(path, payload)
        .then((res) => {
            this.msg = res.data;
            this.add_message = this.msg['message'];
            this.initForm();
        })
        .catch((error) => {
          // eslint-disable-next-line
          console.log(error);
        });
    },
    delData() {
      const path = 'http://localhost:5000/delEntry/';
      axios.delete(path + this.id1)
        .then((res) => {
            this.msg = res.data;
            this.del_message = this.msg['message'];
            this.initForm();
        })
        .catch((error) => {
          // eslint-disable-next-line
          console.log(error);
        });
    },
    onCheck() {
      const payload = {
        id:this.id,
      };
      const path = 'http://localhost:5000/getEntry';
      axios.post(path, payload)
        .then((res) => {
            this.response_delete = res.data;
            
        })
        .catch((error) => {
          // eslint-disable-next-line
          console.log(error);
        });
    },
   onSubmit(evt) {
      evt.preventDefault();
      const payload = {
        id:this.id,
         gender:this.gender,
         Residence_type:this.Residence_type,
         age:this.age,
         hypertension:this.hypertension,
         ever_married:this.ever_married,
         heart_disease:this.heart_disease,
         work_type:this.work_type,
         avg_glucose_level:this.avg_glucose_level,
         bmi:this.bmi,
         smoking_status:this.smoking_status,
         stroke: this.stroke
      };
      this.addData(payload);
    },

    onDelete(evt) {
      evt.preventDefault();
      /*const payload = {
        id:this.id1,
      };*/
      this.delData();
    }


  },
  components: {
    alert: AlertAdd,
    alert_warn: AlertWarn
  },
  created() {

  }
};
</script>

<style scoped>
.styled-input {
  width:100px;
}

.styled-input1 {
  width:250px;
}

.cardText
{
    padding:40px;
    background-size: cover;
    width: 100%;
    height: 100%;
}


</style>