<template>
    <v-container fluid fill-height class="sign-in">
        <v-layout>
           
            <v-flex xs12 sm8 md12 lg6 >
                    <br>
                    <h1> Try our prediction model!! </h1>
                    <br>
                     <v-card class="elevation-24">
                         <v-card-text class="cardText blue-grey darken-4" >
                        <v-form ref="form" >
                             <v-row >
                            <v-select 
                                dark
                                v-model="gender"
                                :items="gendera"
                                label="Gender"
                                class="a1"
                            ></v-select>
                             <v-select 
                                dark
                                v-model="Residence_type"
                                :items="residencea"
                                label="Residence"
                                class="a2"
                            ></v-select>
                             <v-select 
                                dark
                                v-model="smoking_status"
                                :items="smokea"
                                label="Status on smoking"
                                class="a3"
                            ></v-select>
                             </v-row>
                            <v-row >
                                <v-spacer></v-spacer>
                                 <v-checkbox
                                    dark
                                    v-model="hypertension"
                                    label="Hypertension"
                            ></v-checkbox>
                                <v-spacer></v-spacer>
                                  <v-checkbox
                                    dark
                                    v-model="ever_married"
                                    label="Ever been married"
                            ></v-checkbox>
                                <v-spacer></v-spacer>
                             <v-checkbox
                                    dark
                                    v-model="heart_disease"
                                    label="History of heart diseases?"
                                    required
                            ></v-checkbox>
                            <v-spacer></v-spacer>
                            </v-row>
                             <v-card flat dark class="blue-grey darken-4">
                                <v-card-text class="heading head" >
                                    Work type
                                </v-card-text>
                            </v-card>
                             <v-radio-group dark v-model="work_type" row>
                                <v-radio
                                        v-for="(item, index) in work_typea"
                                        :key=index
                                        :label="` ${item}`"
                                        :value="` ${item}`"
                                    ></v-radio>
                            </v-radio-group>
                            <v-row>
                            <v-text-field
                                dark
                                label="Age"
                               filled
                                v-model="age"
                                class= "styled-input"
                            ></v-text-field>
                            <v-text-field dark v-model="bmi" name="bmi" label="BMI" filled class= "styled-input1" required>
                            </v-text-field>
                             <v-text-field dark v-model="avg_glucose_level" name="glucose" class= "styled-input2" label="Average Glucose Level" filled required>
                            </v-text-field>
                            </v-row>
                        </v-form>
                        <v-spacer></v-spacer>
                        <v-row>
                        <v-btn color="green" @click="onSubmit">PREDICT!!</v-btn>
                        <v-spacer></v-spacer>
                         <v-btn color="red" @click="reset">Reset</v-btn>
                         </v-row>
                         </v-card-text>
                        </v-card >
           </v-flex>
        </v-layout>
    </v-container>
</template>

<script>
import axios from 'axios';
//import AlertAdd from '@/components/AlertAdd';
//import AlertWarn from '@/components/AlertWarn';

export default {
  data() {
    return {
         msg:'',
         gender:null,
         Residence_type:null,
         age:'',
         hypertension:false,
         ever_married:false,
         heart_disease:false,
         work_type:null,
         avg_glucose_level:'',
         bmi:'',
         smoking_status:'',
        gendera: [
      'Male',
      'Female'
    ],
     smokea: [
      'never smoked',
      'formerly smoked',
      'smokes'
    ],
     operationa: [
       'Add Data' ,
      'Delete Entry'
    ],

     work_typea: [
      'children',
      'Private',
      'Self-employed',    //fill up the rest
      'Never_worked',
      'Govt_job'
    ],

    residencea: [
      'Urban',
      'Rural'//fill up the rest
    ]
    };
  },
  methods: {
    initForm() {
         this.gender=null;
         this.Residence_type=null;
         this.age='';
         this.hypertension=false;
         this.ever_married=false;
         this.heart_disease=false;
         this.work_type=null;
         this.avg_glucose_level='';
         this.bmi='';
         this.smoking_status='';
    },
    reset(){
        this.initForm();
    },
    predict(payload) {
      const path = 'http://localhost:5000/predict';
      axios.post(path, payload)
        .then((res) => {
            this.msg = res.data;
            // see what the response is and add it to the right side of the screen
            this.initForm();
        })
        .catch((error) => {
          console.log(error);
        });
    },
   onSubmit(evt) {
      evt.preventDefault();
      const payload = {
         gender:this.gender,
         Residence_type:this.Residence_type,
         age:this.age,
         hypertension:this.hypertension,
         ever_married:this.ever_married,
         heart_disease:this.heart_disease,
         work_type:this.work_type,
         avg_glucose_level:this.avg_glucose_level,
         bmi:this.bmi,
         smoking_status:this.smoking_status,
      };
      this.predcit(payload);
    }
 },
  components: {
  },
  created() {

  }
};
</script>

<style scoped>
.styled-input {
  padding:10px;
  width:50px;
}
.styled-input1 {
  padding:10px;
}
.head{
    padding:0;
}
.styled-input2 {
  padding:10px;
}

.a1{
    padding:10px;
    width:50px;
}
.a2{
    padding:10px;
    width:50px;
}

.a3{
    padding:10px;
    width:100px;
}

.cardText
{
    padding:40px;
    background-size: cover;
    width: 100%;
    height: 100%;
}


</style>