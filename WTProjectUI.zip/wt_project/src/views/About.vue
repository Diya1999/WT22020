<template>
    <v-container fluid>
        <v-layout>
            <h1>About Page</h1>
        </v-layout>
    </v-container>
</template>
<script>
export default {
    name: 'About'
};
</script>
<style scoped>
</style>