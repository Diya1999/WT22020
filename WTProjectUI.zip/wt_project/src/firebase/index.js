import firebase from 'firebase';
  // Your web app's Firebase configuration
  var firebaseConfig = {
    apiKey: "AIzaSyCfjK0SFLzNKixmu31SZ8XIyBSi_286zGA",
    authDomain: "mildemo-1.firebaseapp.com",
    databaseURL: "https://mildemo-1.firebaseio.com",
    projectId: "mildemo-1",
    storageBucket: "mildemo-1.appspot.com",
    messagingSenderId: "882287456898",
    appId: "1:882287456898:web:f622835257020fceed7a9b"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
