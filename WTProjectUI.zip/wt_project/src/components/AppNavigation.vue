<template>
    <span>
      
        <v-navigation-drawer app v-model="drawer" class="blue-grey darken-4" dark disable-resize-watcher>
            <v-list>
                <template v-for="(item, index) in items">
                    <v-list-item :key="index">
                        <!--<router-link :to="item.link">-->
                        <v-list-item-content class="white--text">
                            {{item.title}}
                        </v-list-item-content>
                        <!--</router-link>-->
                    </v-list-item>
                    <v-divider :key="`divider-${index}`"></v-divider>
                </template>
            </v-list>
        </v-navigation-drawer>
        <v-app-bar color="blue-grey darken-4" dark>
                <v-app-bar-nav-icon class="hidden-md-and-up"  @click="drawer = !drawer"></v-app-bar-nav-icon>
                
                <v-spacer class="hidden-md-and-up"></v-spacer>
                
                <v-toolbar-title>TITLE</v-toolbar-title>
                
                <v-divider
                    class="mx-4"
                    vertical
                ></v-divider>
                 <router-link to="/">
                 <span class="subheading white--text" to="/">My Home</span>
                 </router-link>
                 <v-spacer class="hidden-sm-and-down"></v-spacer>
                <v-btn text class="hidden-sm-and-down" to="/stats">STATS</v-btn>
                 <v-divider vertical class="hidden-sm-and-down"></v-divider>
                <v-btn text class="hidden-sm-and-down" to="/predictions">PREDICTIONS</v-btn>
                <div v-if="!isAuthenticated" class="hidden-sm-and-down">
                <v-btn color="blue-grey lighten-1" to="/sign-in">SIGN IN</v-btn>
                </div>
                <v-btn v-else outline color="blue-grey lighten-1" @click="logout">Logout</v-btn>
              <!--  <v-btn color="blue-grey lighten-1" class="hidden-sm-and-down" @click.prevent="logout">SIGN OUT</v-btn>-->
        </v-app-bar>
    </span>
    
</template>

<script>

export default {
    name: 'AppNavigation',
    data() {
        return {
            appTitle: 'Title',
            drawer: false,
            items: [
                { title: 'STATS', link:'/stats' },
                { title: 'PREDICTIONS' ,link:'/predictions'},
                { title: 'SIGN IN' ,link:'/sign-in'}
            ]
        };
    },
 computed: {
        isAuthenticated() {
            return this.$store.getters.isAuthenticated;
        }
    },
    methods: {
        logout() {
            this.$store.dispatch('userSignOut');
        }
    }


};
</script>

<style scoped>
a {
    text-decoration: none;
}
</style>