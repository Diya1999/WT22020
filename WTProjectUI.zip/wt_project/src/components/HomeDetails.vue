<template>
    <v-container fluid class="grey darken-4" >
         <v-flex  class="display-2 text-center my-5 white--text">What our website does(what each page means?)</v-flex>
        <v-layout column >
            <v-flex>
                <div class="headline ml-5 mt-3 grey--text text--lighten-1">Heading</div>
                <p class="subheading ml-5 mt-3 grey--text text--darken-1">Subheading</p>
            </v-flex>
            <v-flex>
                <div class="headline ml-5 mt-3 grey--text text--lighten-1">Heading</div>
                <p class="subheading ml-5 mt-3 grey--text text--darken-1">Subheading</p>
            </v-flex>
            <v-flex>
                <div class="headline ml-5 mt-3 grey--text text--lighten-1">Heading</div>
                <p class="subheading ml-5 mt-3 grey--text text--darken-1">Subheading</p>
            </v-flex>
        </v-layout>
        
            <v-flex class="display-1 text-center my-5 pt-2  pb-2 grey--text text--lighten-5 developer"><b>Developers</b></v-flex>
        <v-layout row>
            <v-flex>
                <div class="headline text-center white--text mt-3"> C Diya</div>
                <p class="subheading text-center white--text mt-3">PES1201700246</p>
            </v-flex>
            <v-flex>
                <div class="headline text-center white--text mt-3">Namrata R</div>
                <p class="subheading text-center white--text mt-3">PES1201700921</p>
            </v-flex>
            <v-flex>
                <div class="headline text-center white--text mt-3">Chiranth J</div>
                <p class="subheading text-center white--text mt-3">PES1201701438</p>
            </v-flex>
        </v-layout>
    </v-container>
</template>

<script>
export default {
    name: 'HomeDetails'
};
</script>

<style scoped>
.developer{
    background-color: #616161;
}
.details{
     background-color: #CFD8DC;
}
</style>