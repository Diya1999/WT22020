import Vue from 'vue';
import Router from 'vue-router';
import Home from '../views/Home.vue';
import Ping from '../components/Ping.vue';
import store from '../store';
Vue.use(Router);

export default new Router({
    mode: 'history',
    base: process.env.BASE_URL,
    routes: [
        {
            path: '/',
        name: 'Home',
        component: Home
        },
        {
            path: '/ping',
            name: 'Ping',
            component: Ping,
          },
          {
            path: '/sign-in',
            name: 'Signin',
            component: () => import('../views/Signin.vue')
        },
        {
            name: 'AddUser',
            path: '/ChangeData',
            component: () => import('../views/AddData.vue'),
            beforeRouteEnter: (to, from, next)=>{
                if (store.getters.isAuthenticated) {
                    next()
                } else {
                    next('/')
                }
            }
        },
        {
            path: '/about',
            name: 'about',
            component: () => import('../views/About.vue')
        },
        {
            path: '/stats',
            name: 'STATS',
            component: () => import('../views/STATS.vue')
        },
        {
            path: '/predictions',
            name: 'PREDICTIONS',
            component: () => import('../views/PREDICTIONS.vue')
        }
    ]
});

