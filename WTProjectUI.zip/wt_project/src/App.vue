<template>
    <v-app>
        <app-navigation></app-navigation>

        <v-content transition="slide-x-transition">
            <router-view></router-view>
        </v-content>
        <!-- added by me
        <v-footer dark padless>
             <v-card class="flex" flat tile>
                <v-card-subtitle class="text-center">
                     <strong>C Diya - PES1201700246 Namrata R - PES1201700921Chiranth J - PES1201701438</strong>
                </v-card-subtitle>
                <v-card-text class="py-2 white--text text-center">
                        {{ new Date().getFullYear() }} — <strong>Mini Project Web technology (UE17CS)</strong>
                </v-card-text>
            </v-card>
         </v-footer>
         till here -->
    </v-app>
</template>

<script>
import AppNavigation from '@/components/AppNavigation';

export default {
    name: 'App',
    components: {
        AppNavigation
    }
};
</script>

<style>

</style>